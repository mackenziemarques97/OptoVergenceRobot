function [eyePosX, eyePosY] = fixedEyePos(ai)
    eyePosX = 350; 
    eyePosY = 350; 
end