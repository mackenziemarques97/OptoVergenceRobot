function deliverRewardNotification(dio, numrew)
    for r = 1:numrew
        disp('Yum, reward');
        pause(0.05); %wait short delay
    end
end