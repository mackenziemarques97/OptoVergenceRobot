function deliverRewardNotification(dio)
    pause(0.001);
    disp('Yum, reward');
    pause(0.001);
end